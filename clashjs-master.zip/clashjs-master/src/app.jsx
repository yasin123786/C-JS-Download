import Clash from "./components/ClashRender.js";
export default Clash;
