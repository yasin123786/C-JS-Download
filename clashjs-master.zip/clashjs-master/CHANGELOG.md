# 1.3.0
* Small internal refactor, `ClashJS` was renamed to `ClashCore` and `ClashRender` to differentiate the game state runner and the render.
* Update UI to show better scores.

# 1.2.0

* Upgrades to `react` `16.13`.
* Fixes readme getting started instructions,