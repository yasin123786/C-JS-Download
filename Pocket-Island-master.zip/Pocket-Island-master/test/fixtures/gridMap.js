var FIXTURES = FIXTURES || {};
FIXTURES.gridMap = {
    "0": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [{
            "key": "nature/tree-small-y",
            "x": -10,
            "y": 0,
            "definition": {
                "class": "whackable"
            }
        }],
        "-9": [{
            "key": "nature/tree-small-y",
            "x": -10,
            "y": 0,
            "definition": {
                "class": "whackable"
            }
        }],
        "-8": [],
        "-7": [],
        "-6": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": -1,
            "definition": {
                "class": "farm"
            }
        }],
        "-5": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": -1,
            "definition": {
                "class": "farm"
            }
        }],
        "-4": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }],
        "-3": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }],
        "-2": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }],
        "-1": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }]
    },
    "1": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [{
            "key": "nature/tree-big",
            "x": -9,
            "y": 1,
            "definition": {
                "class": "whackable"
            }
        }],
        "-8": [{
            "key": "nature/tree-big",
            "x": -9,
            "y": 1,
            "definition": {
                "class": "whackable"
            }
        }],
        "-7": [{
            "key": "nature/tree-big",
            "x": -9,
            "y": 1,
            "definition": {
                "class": "whackable"
            }
        }],
        "-6": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": 1,
            "definition": {
                "class": "farm"
            }
        }],
        "-5": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": 1,
            "definition": {
                "class": "farm"
            }
        }],
        "-4": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }],
        "-3": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }],
        "-2": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }],
        "-1": [{
            "key": "buildings/bakery",
            "x": -4,
            "y": 0,
            "definition": {
                "class": "house"
            }
        }]
    },
    "2": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-11": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-10": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-9": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-8": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-7": [],
        "-6": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": 1,
            "definition": {
                "class": "farm"
            }
        }],
        "-5": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": 1,
            "definition": {
                "class": "farm"
            }
        }],
        "-4": [],
        "-3": [{
            "key": "paths/road",
            "x": -3,
            "y": 2,
            "definition": {
                "class": "path"
            }
        }],
        "-2": [],
        "-1": []
    },
    "3": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-11": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-10": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-9": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-8": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-7": [{
            "key": "paths/road",
            "x": -7,
            "y": 3,
            "definition": {
                "class": "path"
            }
        }],
        "-6": [{
            "key": "paths/road",
            "x": -6,
            "y": 3,
            "definition": {
                "class": "path"
            }
        }],
        "-5": [{
            "key": "paths/road",
            "x": -5,
            "y": 3,
            "definition": {
                "class": "path"
            }
        }],
        "-4": [{
            "key": "paths/road",
            "x": -4,
            "y": 3,
            "definition": {
                "class": "path"
            }
        }],
        "-3": [{
            "key": "paths/road",
            "x": -3,
            "y": 3,
            "definition": {
                "class": "path"
            }
        }],
        "-2": [],
        "-1": []
    },
    "4": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        },
        {
            "key": "nature/tree-small-y",
            "x": -12,
            "y": 4,
            "definition": {
                "class": "whackable"
            }
        }],
        "-11": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        },
        {
            "key": "nature/tree-small-y",
            "x": -12,
            "y": 4,
            "definition": {
                "class": "whackable"
            }
        }],
        "-10": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-9": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-8": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-7": [{
            "key": "paths/road",
            "x": -7,
            "y": 4,
            "definition": {
                "class": "path"
            }
        }],
        "-6": [],
        "-5": [{
            "key": "buildings/knights_house",
            "x": -5,
            "y": 4,
            "definition": {
                "class": "uhouse"
            }
        }],
        "-4": [{
            "key": "buildings/knights_house",
            "x": -5,
            "y": 4,
            "definition": {
                "class": "uhouse"
            }
        }],
        "-3": [{
            "key": "buildings/knights_house",
            "x": -5,
            "y": 4,
            "definition": {
                "class": "uhouse"
            }
        }],
        "-2": [],
        "-1": []
    },
    "5": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-11": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-10": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-9": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-8": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-7": [{
            "key": "paths/road",
            "x": -7,
            "y": 5,
            "definition": {
                "class": "path"
            }
        }],
        "-6": [],
        "-5": [{
            "key": "buildings/knights_house",
            "x": -5,
            "y": 4,
            "definition": {
                "class": "uhouse"
            }
        }],
        "-4": [{
            "key": "buildings/knights_house",
            "x": -5,
            "y": 4,
            "definition": {
                "class": "uhouse"
            }
        }],
        "-3": [{
            "key": "buildings/knights_house",
            "x": -5,
            "y": 4,
            "definition": {
                "class": "uhouse"
            }
        }],
        "-2": [{
            "key": "nature/tree-small-y",
            "x": -2,
            "y": 5,
            "definition": {
                "class": "whackable"
            }
        }],
        "-1": [{
            "key": "nature/tree-small-y",
            "x": -2,
            "y": 5,
            "definition": {
                "class": "whackable"
            }
        }]
    },
    "6": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-11": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-10": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-9": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-8": [{
            "key": "buildings/castle_1",
            "x": -12,
            "y": 2,
            "definition": {
                "class": "castle"
            }
        }],
        "-7": [{
            "key": "paths/road",
            "x": -7,
            "y": 6,
            "definition": {
                "class": "path"
            }
        }],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [{
            "key": "nature/tree-small-y",
            "x": -2,
            "y": 6,
            "definition": {
                "class": "whackable"
            }
        }],
        "-1": [{
            "key": "nature/tree-small-y",
            "x": -2,
            "y": 6,
            "definition": {
                "class": "whackable"
            }
        }]
    },
    "7": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [{
            "key": "nature/tree-big",
            "x": -14,
            "y": 7,
            "definition": {
                "class": "whackable"
            }
        }],
        "-13": [{
            "key": "nature/tree-big",
            "x": -14,
            "y": 7,
            "definition": {
                "class": "whackable"
            }
        }],
        "-12": [{
            "key": "nature/tree-big",
            "x": -14,
            "y": 7,
            "definition": {
                "class": "whackable"
            }
        }],
        "-11": [{
            "key": "characters/troll",
            "x": -12,
            "y": 7,
            "definition": {
                "class": "enemy"
            }
        }],
        "-10": [{ // castle road root
            "key": "paths/road",
            "x": -10,
            "y": 7,
            "definition": {
                "class": "path"
            }
        },
        {
            "key": "characters/troll",
            "x": -12,
            "y": 7,
            "definition": {
                "class": "enemy"
            }
        }],
        "-9": [{
            "key": "paths/road",
            "x": -9,
            "y": 7,
            "definition": {
                "class": "path"
            }
        },
        {
            "key": "characters/troll",
            "x": -12,
            "y": 7,
            "definition": {
                "class": "enemy"
            }
        }],
        "-8": [{
            "key": "paths/road",
            "x": -8,
            "y": 7,
            "definition": {
                "class": "path"
            }
        }],
        "-7": [{
            "key": "paths/road",
            "x": -7,
            "y": 7,
            "definition": {
                "class": "path"
            }
        }],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    },
    "8": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    },
    "9": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [{
            "key": "nature/tree-big",
            "x": -3,
            "y": 9,
            "definition": {
                "class": "whackable"
            }
        }],
        "-2": [{
            "key": "nature/tree-big",
            "x": -3,
            "y": 9,
            "definition": {
                "class": "whackable"
            }
        }],
        "-1": [{
            "key": "nature/tree-big",
            "x": -3,
            "y": 9,
            "definition": {
                "class": "whackable"
            }
        }]
    },
    "10": {
        "0": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        },
        {
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [{
            "key": "nature/tree-small-y",
            "x": -14,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-13": [{
            "key": "nature/tree-small-y",
            "x": -14,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [{
            "key": "nature/rock-big-2",
            "x": -9,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-8": [{
            "key": "nature/rock-big-2",
            "x": -9,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-7": [],
        "-6": [{
            "key": "nature/tree-big",
            "x": -6,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-5": [{
            "key": "nature/tree-big",
            "x": -6,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-4": [{
            "key": "nature/tree-big",
            "x": -6,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        },
        {
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }],
        "-3": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }],
        "-2": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }],
        "-1": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }]
    },
    "11": {
        "0": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        },
        {
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [{
            "key": "nature/tree-small-y",
            "x": -12,
            "y": 11,
            "definition": {
                "class": "whackable"
            }
        }],
        "-11": [{
            "key": "nature/tree-small-y",
            "x": -12,
            "y": 11,
            "definition": {
                "class": "whackable"
            }
        }],
        "-10": [],
        "-9": [{
            "key": "nature/rock-big-2",
            "x": -9,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-8": [{
            "key": "nature/rock-big-2",
            "x": -9,
            "y": 10,
            "definition": {
                "class": "whackable"
            }
        }],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }],
        "-3": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }],
        "-2": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }],
        "-1": [{
            "key": "buildings/ship_stage_1",
            "x": -4,
            "y": 10,
            "definition": {
                "class": "ship"
            }
        }]
    },
    "12": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    },
    "13": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    },
    "14": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    },
    "15": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    },
    "-16": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-15": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-14": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-13": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-12": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-11": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-10": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-9": {
        "0": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/5",
            "x": 0,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/2",
            "x": -16,
            "y": -16,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-8": {
        "0": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-7": {
        "0": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-6": {
        "0": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-5": {
        "0": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-4": {
        "0": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "buildings/lighthouse",
            "x": -13,
            "y": -6,
            "definition": {
                "class": "statichouse"
            }
        },
        {
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-3": {
        "0": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/4",
            "x": 0,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-15": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-14": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-13": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-12": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-11": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-10": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-9": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-8": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-7": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-6": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-5": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-4": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-3": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-2": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-1": [{
            "key": "unlock/1",
            "x": -16,
            "y": -8,
            "definition": {
                "class": "unlockable"
            }
        }]
    },
    "-2": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [],
        "-5": [],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    },
    "-1": {
        "0": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "1": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "2": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "3": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "4": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "5": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "6": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "7": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "8": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "9": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "10": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "11": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "12": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "13": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "14": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "15": [{
            "key": "unlock/3",
            "x": 0,
            "y": -2,
            "definition": {
                "class": "unlockable"
            }
        }],
        "-16": [],
        "-15": [],
        "-14": [],
        "-13": [],
        "-12": [],
        "-11": [],
        "-10": [],
        "-9": [],
        "-8": [],
        "-7": [],
        "-6": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": -1,
            "definition": {
                "class": "farm"
            }
        }],
        "-5": [{
            "key": "farming/basic_plot",
            "x": -6,
            "y": -1,
            "definition": {
                "class": "farm"
            }
        }],
        "-4": [],
        "-3": [],
        "-2": [],
        "-1": []
    }
}